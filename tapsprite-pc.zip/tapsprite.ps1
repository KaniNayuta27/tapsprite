# TapSprite desktop console — talks to tapsprite.pages.dev, no browser.
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$HostUrl = "https://tapsprite.pages.dev"
$After = 0
$Timer = $null

$Bg = [System.Drawing.Color]::FromArgb(11, 13, 12)
$Elev = [System.Drawing.Color]::FromArgb(20, 24, 22)
$Fg = [System.Drawing.Color]::FromArgb(238, 242, 239)
$Muted = [System.Drawing.Color]::FromArgb(139, 148, 142)
$Accent = [System.Drawing.Color]::FromArgb(197, 212, 204)
$Mono = New-Object System.Drawing.Font("Consolas", 10)
$Ui = New-Object System.Drawing.Font("Microsoft YaHei UI", 9)

$form = New-Object System.Windows.Forms.Form
$form.Text = "触控精灵  ·  电脑端"
$form.Size = New-Object System.Drawing.Size(1120, 740)
$form.StartPosition = "CenterScreen"
$form.BackColor = $Bg
$form.ForeColor = $Fg
$form.MinimumSize = New-Object System.Drawing.Size(900, 560)

function New-Label($text, $x, $y, $w) {
  $l = New-Object System.Windows.Forms.Label
  $l.Text = $text
  $l.Location = New-Object System.Drawing.Point($x, $y)
  $l.Size = New-Object System.Drawing.Size($w, 22)
  $l.ForeColor = $Muted
  $l.Font = $Ui
  $l
}

$top = New-Object System.Windows.Forms.Panel
$top.Dock = "Top"
$top.Height = 56
$top.BackColor = $Elev
$form.Controls.Add($top)

$lRoom = New-Label "房间码" 16 18 54
$top.Controls.Add($lRoom)

$txtRoom = New-Object System.Windows.Forms.TextBox
$txtRoom.Location = New-Object System.Drawing.Point(74, 14)
$txtRoom.Size = New-Object System.Drawing.Size(120, 28)
$txtRoom.Font = New-Object System.Drawing.Font("Consolas", 14)
$txtRoom.CharacterCasing = "Upper"
$txtRoom.MaxLength = 8
$txtRoom.BackColor = $Bg
$txtRoom.ForeColor = $Accent
$txtRoom.BorderStyle = "FixedSingle"
$top.Controls.Add($txtRoom)

$btnGo = New-Object System.Windows.Forms.Button
$btnGo.Text = "连接手机"
$btnGo.Location = New-Object System.Drawing.Point(206, 13)
$btnGo.Size = New-Object System.Drawing.Size(100, 30)
$btnGo.FlatStyle = "Flat"
$btnGo.BackColor = $Fg
$btnGo.ForeColor = $Bg
$btnGo.Font = $Ui
$top.Controls.Add($btnGo)

$lblStatus = New-Label "填 App 上的 6 位房间码。不需要同一 Wi-Fi。" 320 18 760
$lblStatus.ForeColor = $Accent
$top.Controls.Add($lblStatus)

$split.Dock = "Fill"
$split.BackColor = $Bg
$split.SplitterDistance = 620
$split.SplitterWidth = 8
$form.Controls.Add($split)
$form.Controls.Add($top)

$left = New-Object System.Windows.Forms.Panel
$left.Dock = "Fill"
$left.Padding = New-Object System.Windows.Forms.Padding(12)
$split.Panel1.Controls.Add($left)

$scriptBox = New-Object System.Windows.Forms.TextBox
$scriptBox.Multiline = $true
$scriptBox.ScrollBars = "Both"
$scriptBox.WordWrap = $false
$scriptBox.Dock = "Fill"
$scriptBox.Font = $Mono
$scriptBox.BackColor = $Bg
$scriptBox.ForeColor = $Accent
$scriptBox.BorderStyle = "FixedSingle"
$scriptBox.AcceptsTab = $true
$scriptBox.Text = @"
local w = GetScreenX()
local h = GetScreenY()
TracePrint("屏幕 " .. w .. "x" .. h)
Delay(500)
KeyPress("Home")
Delay(800)
"@
$left.Controls.Add($scriptBox)

$btns = New-Object System.Windows.Forms.FlowLayoutPanel
$btns.Dock = "Bottom"
$btns.Height = 48
$btns.Padding = New-Object System.Windows.Forms.Padding(8, 8, 8, 8)
$left.Controls.Add($btns)

function New-Btn($text) {
  $b = New-Object System.Windows.Forms.Button
  $b.Text = $text
  $b.AutoSize = $true
  $b.Height = 32
  $b.FlatStyle = "Flat"
  $b.BackColor = $Elev
  $b.ForeColor = $Fg
  $b.Font = $Ui
  $b.Margin = New-Object System.Windows.Forms.Padding(0, 0, 8, 0)
  $b
}

$btnSend = New-Btn "发送到手机"
$btnSend.BackColor = $Fg
$btnSend.ForeColor = $Bg
$btnRun = New-Btn "发送并运行"
$btnStart = New-Btn "开始"
$btnStop = New-Btn "停止"
$btnGuide = New-Btn "命令指南"
$btns.Controls.AddRange(@($btnSend, $btnRun, $btnStart, $btnStop, $btnGuide))

$right = New-Object System.Windows.Forms.Panel
$right.Dock = "Fill"
$right.Padding = New-Object System.Windows.Forms.Padding(8, 12, 12, 12)
$split.Panel2.Controls.Add($right)

$logBox = New-Object System.Windows.Forms.TextBox
$logBox.Multiline = $true
$logBox.ScrollBars = "Vertical"
$logBox.ReadOnly = $true
$logBox.Dock = "Fill"
$logBox.Font = New-Object System.Drawing.Font("Consolas", 9)
$logBox.BackColor = $Bg
$logBox.ForeColor = $Accent
$logBox.BorderStyle = "FixedSingle"
$right.Controls.Add($logBox)

function RoomUrl($path) {
  $code = $txtRoom.Text.Trim().ToUpper()
  return "$HostUrl/api/room/$code$path"
}

function Log-Line($msg) {
  $ts = Get-Date -Format "HH:mm:ss"
  $logBox.AppendText("$ts  $msg`r`n")
}

function Api($method, $path, $body) {
  $code = $txtRoom.Text.Trim().ToUpper()
  if ($code.Length -lt 4) { throw "先填房间码" }
  $url = RoomUrl $path
  if ($method -eq "GET") {
    return Invoke-RestMethod -Uri $url -Method GET -TimeoutSec 8
  }
  $json = $body | ConvertTo-Json -Compress
  return Invoke-RestMethod -Uri $url -Method POST -Body $json -ContentType "application/json; charset=utf-8" -TimeoutSec 8
}

function Poll {
  try {
    $r = Api "GET" "?after=$After"
    $phone = $false
    if ($r.phoneSeenAt -and (([DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()) - $r.phoneSeenAt) -lt 8000) {
      $phone = $true
    }
    $run = if ($r.running) { "运行中" } else { "待命" }
    $online = if ($phone) { "手机在线" } else { "等待手机" }
    $lblStatus.Text = "$online  ·  $run  ·  $($r.step)"
    foreach ($line in @($r.lines)) {
      if ($line.seq -gt $After) {
        $After = $line.seq
        $t = [DateTimeOffset]::FromUnixTimeMilliseconds([int64]$line.t).LocalDateTime.ToString("HH:mm:ss")
        $logBox.AppendText("$t  $($line.msg)`r`n")
      }
    }
  } catch {
    $lblStatus.Text = "连不上：" + $_.Exception.Message
  }
}

$btnGo.Add_Click({
  $script:After = 0
  $logBox.Clear()
  Log-Line "连接房间 $($txtRoom.Text.ToUpper())"
  Poll
})

$btnSend.Add_Click({
  try {
    Api "POST" "/script" @{ script = $scriptBox.Text; run = $false } | Out-Null
    Log-Line "已发送脚本"
  } catch { Log-Line $_.Exception.Message }
})
$btnRun.Add_Click({
  try {
    Api "POST" "/script" @{ script = $scriptBox.Text; run = $true } | Out-Null
    Log-Line "已发送并请求运行"
  } catch { Log-Line $_.Exception.Message }
})
$btnStart.Add_Click({
  try { Api "POST" "/control" @{ action = "start" } | Out-Null } catch { Log-Line $_.Exception.Message }
})
$btnStop.Add_Click({
  try { Api "POST" "/control" @{ action = "stop" } | Out-Null } catch { Log-Line $_.Exception.Message }
})
$btnGuide.Add_Click({
  $g = Join-Path $PSScriptRoot "GUIDE.md"
  if (Test-Path $g) { Start-Process $g } else { Start-Process "$HostUrl" }
})

$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 700
$timer.Add_Tick({ if ($txtRoom.Text.Trim().Length -ge 4) { Poll } })
$timer.Start()
$form.Add_FormClosed({ $timer.Stop() })

[void]$form.ShowDialog()
