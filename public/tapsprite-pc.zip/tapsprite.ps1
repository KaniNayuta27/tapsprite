﻿# TapSprite desktop console. Encoding: UTF-8 with BOM (required by Windows PowerShell 5).
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
[System.Windows.Forms.Application]::EnableVisualStyles()

$HostUrl = 'https://tapsprite.pages.dev'
$script:After = 0

$Bg = [System.Drawing.Color]::FromArgb(11, 13, 12)
$Elev = [System.Drawing.Color]::FromArgb(20, 24, 22)
$Fg = [System.Drawing.Color]::FromArgb(238, 242, 239)
$Muted = [System.Drawing.Color]::FromArgb(139, 148, 142)
$Accent = [System.Drawing.Color]::FromArgb(197, 212, 204)
$Mono = New-Object System.Drawing.Font('Consolas', 10)
$Ui = New-Object System.Drawing.Font('Microsoft YaHei UI', 9)

function U([int[]]$codes) {
  $s = ''
  foreach ($c in $codes) { $s += [char]$c }
  return $s
}

$form = New-Object System.Windows.Forms.Form
$form.Text = (U 0x89E6,0x63A7,0x7CBE,0x7075) + '  PC'
$form.Size = New-Object System.Drawing.Size(1120, 740)
$form.StartPosition = [System.Windows.Forms.FormStartPosition]::CenterScreen
$form.BackColor = $Bg
$form.ForeColor = $Fg
$form.MinimumSize = New-Object System.Drawing.Size(900, 560)

function New-Label($text, $x, $y, $w) {
  $l = New-Object System.Windows.Forms.Label
  $l.Text = $text
  $l.Location = New-Object System.Drawing.Point($x, $y)
  $l.Size = New-Object System.Drawing.Size($w, 22)
  $l.ForeColor = $Muted
  $l.Font = $Ui
  return $l
}

$top = New-Object System.Windows.Forms.Panel
$top.Dock = [System.Windows.Forms.DockStyle]::Top
$top.Height = 56
$top.BackColor = $Elev

$lRoom = New-Label (U 0x623F,0x95F4,0x7801) 16 18 54
$top.Controls.Add($lRoom)

$txtRoom = New-Object System.Windows.Forms.TextBox
$txtRoom.Location = New-Object System.Drawing.Point(74, 14)
$txtRoom.Size = New-Object System.Drawing.Size(120, 28)
$txtRoom.Font = New-Object System.Drawing.Font('Consolas', 14)
$txtRoom.CharacterCasing = 'Upper'
$txtRoom.MaxLength = 8
$txtRoom.BackColor = $Bg
$txtRoom.ForeColor = $Accent
$txtRoom.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
$top.Controls.Add($txtRoom)

$btnGo = New-Object System.Windows.Forms.Button
$btnGo.Text = U 0x8FDE,0x63A5,0x624B,0x673A
$btnGo.Location = New-Object System.Drawing.Point(206, 13)
$btnGo.Size = New-Object System.Drawing.Size(100, 30)
$btnGo.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
$btnGo.BackColor = $Fg
$btnGo.ForeColor = $Bg
$btnGo.Font = $Ui
$top.Controls.Add($btnGo)

$lblStatus = New-Label (U 0x586B,0x624B,0x673A,0x4E0A,0x7684,0x623F,0x95F4,0x7801) 320 18 760
$lblStatus.ForeColor = $Accent
$top.Controls.Add($lblStatus)

$split = New-Object System.Windows.Forms.SplitContainer
$split.Dock = [System.Windows.Forms.DockStyle]::Fill
$split.BackColor = $Bg
$split.SplitterWidth = 8
$split.SplitterDistance = 620

$form.Controls.Add($split)
$form.Controls.Add($top)

$left = New-Object System.Windows.Forms.Panel
$left.Dock = [System.Windows.Forms.DockStyle]::Fill
$left.Padding = New-Object System.Windows.Forms.Padding(12)
$split.Panel1.Controls.Add($left)

$scriptBox = New-Object System.Windows.Forms.TextBox
$scriptBox.Multiline = $true
$scriptBox.ScrollBars = [System.Windows.Forms.ScrollBars]::Both
$scriptBox.WordWrap = $false
$scriptBox.Dock = [System.Windows.Forms.DockStyle]::Fill
$scriptBox.Font = $Mono
$scriptBox.BackColor = $Bg
$scriptBox.ForeColor = $Accent
$scriptBox.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
$scriptBox.AcceptsTab = $true
$nl = [Environment]::NewLine
$scriptBox.Text = 'GetScreen' + $nl + 'Delay 500' + $nl + 'KeyPress "Home"' + $nl + 'Delay 800' + $nl
$left.Controls.Add($scriptBox)

$btns = New-Object System.Windows.Forms.FlowLayoutPanel
$btns.Dock = [System.Windows.Forms.DockStyle]::Bottom
$btns.Height = 48
$btns.Padding = New-Object System.Windows.Forms.Padding(8, 8, 8, 8)
$left.Controls.Add($btns)

function New-Btn($text) {
  $b = New-Object System.Windows.Forms.Button
  $b.Text = $text
  $b.AutoSize = $true
  $b.Height = 32
  $b.FlatStyle = [System.Windows.Forms.FlatStyle]::Flat
  $b.BackColor = $Elev
  $b.ForeColor = $Fg
  $b.Font = $Ui
  $b.Margin = New-Object System.Windows.Forms.Padding(0, 0, 8, 0)
  return $b
}

$btnSend = New-Btn (U 0x53D1,0x9001,0x5230,0x624B,0x673A)
$btnSend.BackColor = $Fg
$btnSend.ForeColor = $Bg
$btnRun = New-Btn (U 0x53D1,0x9001,0x5E76,0x8FD0,0x884C)
$btnStart = New-Btn (U 0x5F00,0x59CB)
$btnStop = New-Btn (U 0x505C,0x6B62)
$btnGuide = New-Btn (U 0x6307,0x5357)
$btns.Controls.AddRange(@($btnSend, $btnRun, $btnStart, $btnStop, $btnGuide))

$right = New-Object System.Windows.Forms.Panel
$right.Dock = [System.Windows.Forms.DockStyle]::Fill
$right.Padding = New-Object System.Windows.Forms.Padding(8, 12, 12, 12)
$split.Panel2.Controls.Add($right)

$logBox = New-Object System.Windows.Forms.TextBox
$logBox.Multiline = $true
$logBox.ScrollBars = [System.Windows.Forms.ScrollBars]::Vertical
$logBox.ReadOnly = $true
$logBox.Dock = [System.Windows.Forms.DockStyle]::Fill
$logBox.Font = New-Object System.Drawing.Font('Consolas', 9)
$logBox.BackColor = $Bg
$logBox.ForeColor = $Accent
$logBox.BorderStyle = [System.Windows.Forms.BorderStyle]::FixedSingle
$right.Controls.Add($logBox)

function RoomUrl($path) {
  $code = $txtRoom.Text.Trim().ToUpper()
  return ($HostUrl + '/api/room/' + $code + $path)
}

function Log-Line($msg) {
  $ts = Get-Date -Format 'HH:mm:ss'
  $logBox.AppendText($ts + '  ' + $msg + "`r`n")
}

function Api($method, $path, $body) {
  $code = $txtRoom.Text.Trim().ToUpper()
  if ($code.Length -lt 4) { throw 'Enter room code first' }
  $url = RoomUrl $path
  if ($method -eq 'GET') {
    return Invoke-RestMethod -Uri $url -Method GET -TimeoutSec 8
  }
  $json = $body | ConvertTo-Json -Compress
  $bytes = [System.Text.Encoding]::UTF8.GetBytes($json)
  return Invoke-RestMethod -Uri $url -Method POST -Body $bytes -ContentType 'application/json; charset=utf-8' -TimeoutSec 8
}

function Poll {
  try {
    $r = Api 'GET' ('?after=' + $script:After)
    $phone = $false
    if ($r.phoneSeenAt) {
      $now = [DateTimeOffset]::UtcNow.ToUnixTimeMilliseconds()
      if (($now - $r.phoneSeenAt) -lt 8000) { $phone = $true }
    }
    $run = 'idle'
    if ($r.running) { $run = 'running' }
    $online = 'waiting phone'
    if ($phone) { $online = 'phone online' }
    $lblStatus.Text = $online + '  |  ' + $run + '  |  ' + $r.step
    foreach ($line in @($r.lines)) {
      if ($line.seq -gt $script:After) {
        $script:After = $line.seq
        $t = [DateTimeOffset]::FromUnixTimeMilliseconds([int64]$line.t).LocalDateTime.ToString('HH:mm:ss')
        $logBox.AppendText($t + '  ' + $line.msg + "`r`n")
      }
    }
  } catch {
    $lblStatus.Text = 'error: ' + $_.Exception.Message
  }
}

$btnGo.Add_Click({
  $script:After = 0
  $logBox.Clear()
  Log-Line ('connect ' + $txtRoom.Text.ToUpper())
  Poll
})

$btnSend.Add_Click({
  try {
    Api 'POST' '/script' @{ script = $scriptBox.Text; run = $false } | Out-Null
    Log-Line 'script sent'
  } catch { Log-Line $_.Exception.Message }
})
$btnRun.Add_Click({
  try {
    Api 'POST' '/script' @{ script = $scriptBox.Text; run = $true } | Out-Null
    Log-Line 'sent + run'
  } catch { Log-Line $_.Exception.Message }
})
$btnStart.Add_Click({
  try { Api 'POST' '/control' @{ action = 'start' } | Out-Null } catch { Log-Line $_.Exception.Message }
})
$btnStop.Add_Click({
  try { Api 'POST' '/control' @{ action = 'stop' } | Out-Null } catch { Log-Line $_.Exception.Message }
})
$btnGuide.Add_Click({
  $g = Join-Path $PSScriptRoot 'GUIDE.md'
  if (Test-Path $g) { Start-Process $g } else { Start-Process ($HostUrl + '/GUIDE.md') }
})

$timer = New-Object System.Windows.Forms.Timer
$timer.Interval = 700
$timer.Add_Tick({ if ($txtRoom.Text.Trim().Length -ge 4) { Poll } })
$timer.Start()
$form.Add_FormClosed({ $timer.Stop() })

[void]$form.ShowDialog()
